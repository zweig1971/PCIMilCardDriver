#ifndef _PRINT_STRUCT_H_
#define _PRINT_STRUCT_H_

#ifdef __cplusplus
extern "C" {
#endif

void WD_CARD_print(WD_CARD *pCard, PCHAR pcPrefix);

#ifdef __cplusplus
}
#endif

#endif
